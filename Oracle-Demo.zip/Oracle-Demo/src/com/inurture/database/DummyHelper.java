package com.inurture.database;

import java.util.List;

import com.inurture.entities.Author;
import com.inurture.entities.Book;

public class DummyHelper implements DatabaseHandler{

	@Override
	public Book getBookDetailsByISBN(String ISBN) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author getAuthorDetails(String identifier) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getBookList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getBooksForAuthor(String authorNumner) {
		// TODO Auto-generated method stub
		return null;
	}

}
