package com.inurture.database;

public interface SecurityAdapter {
	public boolean verifyUser(String username);
	public String verifyPassword(String username, String password);
	public boolean verifyToken(String token);
}
