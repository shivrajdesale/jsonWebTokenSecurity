package com.inurture.database;

import java.util.List;

import com.inurture.entities.Book;

public class BookManager {

	private String DummyMode = "Dummy";
	private String OracleMode = "Oracle";
	private String mode = "";
	private DatabaseHandler databaseHandler;
	private BookManager() {
		this.mode = DummyMode;
	}
	
	public static List<Book> getBookList() {
		return null;
	}
}
