package com.inurture.database;

public class SecurityHandler {
	
	public boolean verifyUser(String username) {
		return false;
	}
	public String verifyPassword(String username, String password) {
		return null;
	}
	public boolean verifyToken(String token) {
		return false;
	}
}
