package com.inurture.database;

import java.util.List;

import com.inurture.entities.Author;
import com.inurture.entities.Book;

public interface DatabaseHandler {
	
	public Book getBookDetailsByISBN(String ISBN);
	public Author getAuthorDetails(String identifier);
	public List<Book> getBookList();
	public List<Book> getBooksForAuthor(String authorNumner);
	
}
