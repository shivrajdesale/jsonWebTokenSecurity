package com.inurture.entities;

public enum Gender {
	MALE, FEMALE, TRANS;
}
