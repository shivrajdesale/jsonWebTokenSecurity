package com.inurture.entities;

public class Book {
	private String ISBN;
	private Author author;
	private String BookName;
	private String coverPageImage;
	private String publicationYear;
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getCoverPageImage() {
		return coverPageImage;
	}
	public void setCoverPageImage(String coverPageImage) {
		this.coverPageImage = coverPageImage;
	}
	public String getPublicationYear() {
		return publicationYear;
	}
	public void setPublicationYear(String publicationYear) {
		this.publicationYear = publicationYear;
	}
}
